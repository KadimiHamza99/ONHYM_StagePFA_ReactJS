import React from 'react';

const Footer = () => {
    return (
        <div className="text-center p-4 footer">
            © 2021 Copyright: KADIMI Hamza
        </div>
    );
};

export default React.memo(Footer)